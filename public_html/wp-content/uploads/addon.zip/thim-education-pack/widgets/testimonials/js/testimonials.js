(function ($) {
	$(document).ready(function () {
		$(".thim-testimonials").owlCarousel({
			items      : 1,
			autoPlay   : 4000,
			stopOnHover: true,
			pagination : false,
			autoHeight : false,
			mousewheel : true
		});
	});
})(jQuery);